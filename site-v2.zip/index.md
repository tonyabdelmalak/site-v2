---
layout: politico
toc: true
title: Tony Abdelmalak | AI-Driven People & Business Insights Analyst
---
{%- comment -%}
  This file uses the Politico-style layout for the duplicated site.  To preserve
  all existing links, the original homepage HTML should be placed in the
  adjacent `_index-raw.html` file.  The layout will wrap that HTML and
  automatically generate a sticky table of contents and reading progress bar.
{%- endcomment -%}

{% include_relative _index-raw.html %}